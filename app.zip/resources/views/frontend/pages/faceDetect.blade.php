
@extends('layouts.frontend')

@section('main')
	<h1>Chương Trình Nhận diện Gương Mặt</h1>
	<p id="loading">Hệ thống đang tải dữ liệu ... </p>
	<input type="file" name="file" id="file-input" />
	<div id="pic-content"></div>

	{{-- <div class="container">
		@foreach ($personList as $user)
			{{ $user->personName }}
		@endforeach
	</div>
	
	{!! $personList->links() !!} --}}
	
@endsection


@push('script')
    const labels = [];
    @foreach($personList as $name)
        {{-- let x = '{{$name}}';
        // x.push({{$name}}); --}}
        labels.push('{{$name->personName}}');
    @endforeach
        
@endpush