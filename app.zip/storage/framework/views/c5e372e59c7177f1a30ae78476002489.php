


<?php $__env->startSection('main'); ?>
	<h1>Chương Trình Nhận diện Gương Mặt</h1>
	<p id="loading">Hệ thống đang tải dữ liệu ... </p>
	<input type="file" name="file" id="file-input" />
	<div id="pic-content"></div>

	
	
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    const labels = [];
    <?php $__currentLoopData = $personList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        labels.push('<?php echo e($name->personName); ?>');
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard\new-laravel\resources\views/frontend/pages/faceDetect.blade.php ENDPATH**/ ?>