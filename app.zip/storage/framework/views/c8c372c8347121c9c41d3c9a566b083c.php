<div class="container">
    <table class="table table-bordered">
        <tr>
            <th>Id</th>
            <th>Title</th>
        </tr>
        
    </table>
</div>
<?php echo e(gettype($list)); ?>

<?php echo e(var_dump($list)); ?>

<?php echo e(var_dump($myArr)); ?>

<?php /**PATH C:\xampp\htdocs\dashboard\new-laravel\resources\views/paginate.blade.php ENDPATH**/ ?>