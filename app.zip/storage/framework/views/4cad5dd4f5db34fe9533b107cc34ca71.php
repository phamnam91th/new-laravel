

<?php $__env->startSection('content'); ?>
	<div class="dashboard container-fluid  pt-4">
		<h1 class="text-center text-warning mt-3">DASHBOARD PAGE</h1>
        <div class="menu-body bg-dark border border-warning rounded rounded-3">
            <table class="table table-dark home-menu container mt-2">
                <tr d-flex flex-wrap justify>
                    <td class="text-start align-middle"><div><a class="fw-bold text-light text-decoration-none"  href="<?php echo e(route('personList')); ?>" ><i class="bi bi-building-add"></i>  Person List</a></div></td>
                    <td class="text-start align-middle"><div><a class="fw-bold text-light text-decoration-none"  href="" ><i class="bi bi-person"></i>  New Item</a></div></td>
                    <td class="text-start align-middle"><div><a class="fw-bold text-light text-decoration-none"  href="" ><i class="bi bi-person-bounding-box"></i>  Employee</a></div></td>
                    <td class="text-start align-middle"><div><a class="fw-bold text-light text-decoration-none"  href="" ><i class="bi bi-person-fill-add"></i>  Member</a></div></td>
                    <td class="text-start align-middle"><div><a class="fw-bold text-light text-decoration-none"  href="" ><i class="bi bi-person-workspace"></i>  Person Trainer</a></div></td>
                </tr>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldContent('personList'); ?>



<?php $__env->startSection('insert'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard\new-laravel\resources\views/CRUD/dashboard.blade.php ENDPATH**/ ?>