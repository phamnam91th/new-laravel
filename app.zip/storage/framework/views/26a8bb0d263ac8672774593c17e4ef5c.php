
<head>
	
</head>
<?php $__env->startSection('head'); ?>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('css/faceDetect.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>Chương Trình Nhận diện Gương Mặt</h1>
	<p id="loading">Hệ thống đang tải dữ liệu ... </p>
	<input type="file" name="file" id="file-input" />
	<div id="pic-content"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('insert'); ?>
	<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
	<script src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.js" integrity="sha256-JOJ7NmVm2chxYZ1KPcAYd2bwVK7NaFj9QKMp7DClews=" crossorigin="anonymous"></script>
	<script src="<?php echo e(asset('./js/scripts.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashboard\new-laravel\resources\views/faceDetect.blade.php ENDPATH**/ ?>