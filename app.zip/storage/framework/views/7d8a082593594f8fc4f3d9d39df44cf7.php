<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        .pagination {
            display: flex;
            gap: 20px  ;
            list-style-type: none;
        }
        .pagination .page-link {
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php $__currentLoopData = $listName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            
            <td><?php echo e($user); ?></td> 
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <?php echo e($listName->links()); ?>

    <?php echo e(gettype($listName)); ?>

    
</body>
</html>

<?php /**PATH C:\xampp\htdocs\dashboard\new-laravel\resources\views/frontend/pages/test.blade.php ENDPATH**/ ?>