<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Nhận diện Hình Ảnh</title>
	<style>
		#container {
			width: 100%;
			position: relative;
		}

		#container img {
			width: 100%;
			height: auto;
		}

		canvas {
			position: absolute;
			top: 0;
			left: 0;
		}
	</style>
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

</head>

<body>
	<h1>Chương Trình Nhận diện Gương Mặt</h1>

	<p id="loading">Hệ thống đang tải dữ liệu ... </p>
	<input type="file" name="file" id="file-input" />

	<div id="container"></div>
</body>

<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script src="https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.js" integrity="sha256-JOJ7NmVm2chxYZ1KPcAYd2bwVK7NaFj9QKMp7DClews=" crossorigin="anonymous"></script>

<script src="<?php echo e(resources.js.); ?>"></script>

</html><?php /**PATH C:\xampp\htdocs\dashboard\new-laravel\resources\views/face-detect.blade.php ENDPATH**/ ?>